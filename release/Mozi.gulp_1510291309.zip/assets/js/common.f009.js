$(function() {

	'use strict';

	console.log('Mozi.gulp!');

});